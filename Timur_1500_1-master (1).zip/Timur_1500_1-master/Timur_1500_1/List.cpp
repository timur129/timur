#include <iostream>
#include "List.h"

List::Node::Node(int value, List::Node* prev, List::Node* next) {
	_value = value;
	_prev = prev;
	_next = next;
}

int List::Node::getValue()  {
	return _value;
}

List::Node* List::Node::getPrev() {
	return _prev;
}

List::Node* List::Node::getNext() {
	return _next;
}

void List::Node::setValue(int value) {
	_value = value;
}

void List::Node::setPrev(Node* prev) {
	_prev = prev;
}

void List::Node::setNext(Node* next) {
	_next = next;
}



List::List() {
	_head = nullptr;
	_tail = nullptr;
	_size = 0;
}

List::~List() {
	clear();
}

List::Node* List::getHead() {
	return _head;
}

void List::push_back(int value) {
	if (_size == 0) {
		_head = new Node(value, nullptr, nullptr);
		_tail = _head;
		_size++;
		return;
	}
	_tail->setNext(new Node(value, _tail, nullptr));
	_tail = _tail->getNext();
	_size++;
}

void List::push_front(int value) {
	if (_size == 0) {
		_head = new Node(value, nullptr, nullptr);
		_tail = _head;
		_size++;
		return;
	}
	_head->setPrev(new Node(value, nullptr, _head));
	_head = _head->getPrev();
	_size++;
}

void List::pop_back() {
	if (_size == 0)
		return;
	if (_size == 1) {
		delete _head;
		_head = nullptr;
		_tail = _head;
		_size = 0;
		return;
	}
	_tail = _tail->getPrev();
	delete _tail->getNext();
	_tail->setNext(nullptr);
	_size--;
}

void List::pop_front() {
	if (_size == 0)
		return;
	if (_size == 1) {
		delete _head;
		_head = nullptr;
		_tail = _head;
		_size = 0;
		return;
	}
	_head = _head->getNext();
	delete _tail->getNext();
	_head->setPrev(nullptr);
	_size--;
}

void List::insert(int value, size_t index) {
	if (index > _size || index < 0)
		return;
	if (index == 0) {
		push_front(value);
		return;
	}
	if (index == (_size - 1)) {
		push_back(value);
		return;
	}
	Node* iterator = _head;
	for (size_t i = 0; i < index; i++) {
		iterator = iterator->getNext();
	}
	iterator->getPrev()->setNext(new Node(value, iterator->getPrev(), iterator));
	iterator->getNext()->setPrev(iterator);
	_size++;

}

int List::at(size_t index) {
	if (index >= _size || index < 0)
		return -1;
	Node* iterator = _head;
	for (size_t i = 0; i < index; i++) {
		iterator = iterator->getNext();
	}
	return iterator->getValue();
}

void List::remove(size_t index) {
	if (index >= _size || index < 0)
		return;
	if (index == 0) {
		pop_front();
		return;
	}
	if (index == (_size - 1)) {
		pop_back();
		return;
	}

	Node* iterator = _head;
	Node* buf;
	for (size_t i = 0; i < index - 1; i++) {
		iterator = iterator->getNext();
	}
	buf = iterator->getNext();
	iterator->setNext(buf->getNext());
	iterator->getNext()->setPrev(iterator);
	delete buf;
	_size--;
}

size_t List::get_size() {
	return _size;
}

void List::print_to_console() {
	Node* iterator = _head;
	while (iterator) {
		std::cout << iterator->getValue();
		std::cout << " ";
		iterator = iterator->getNext();
	}
	std::cout << '\n';
}

void List::clear() {
	while (_head)
		pop_back();
}

void List::set(size_t index, int value) {
	if (index >= _size || index < 0)
		return;
	Node* iterator = _head;
	for (size_t i = 0; i < index; i++) {
		iterator = iterator->getNext();
	}
	iterator->setValue(value);
}

bool List::isEmpty() {
	return !(bool)_size;
}

void List::push_back(List list) {
	Node* iterator = list.getHead();
	while (iterator) {
		push_back(iterator->getValue());
		iterator = iterator->getNext();
	}
	_size++;
}