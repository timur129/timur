#include "List.h"

int main() {
	List* list = new List();
	list->push_back(5);
	list->push_back(6);
	list->push_back(7);
	list->push_back(8);
	list->set(1, 9);
	list->print_to_console();
	return 0;
}